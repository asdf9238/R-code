library(xlsx)

setwd('C:\\Users\\ParkSejin\\Desktop\\[확률과 통계 8조] R코드 및 발표자료\\사용된 데이터 파일')
getwd()

#########################################################################
#ppt에 삽입된 그래프에 대한 코드들
#########################################################################

#배달비 관련 소비자 상담 접수건 코드
Counseling <- read.xlsx('배달비 관련 소비자 상담 접수건.xlsx', header = T, sheetIndex = 1)
Counseling_year <- c(2017, 2018, 2019, 2020, 2021)
plot(Counseling_year, Counseling[1, -1],
     main = '배달비 관련 소비자 상담 접수건',
     xlab = '년도(년)',
     ylab = '건수',
     col = 'red',
     type = 'b')


#전세계 음식 배달 시장의 크기 코드
delivery_market <- c(119, 389, 616)
delivery_market <- rbind(delivery_market, c(2018, 2021, 2026))
delivery_market
plot(delivery_market[2, ], delivery_market[1,], 
        main = '전세계 음식 배달 시장의 크기',
        xlab = '년도(년)',
        ylab = '시장의 크기(조)',
        col = 'red',
        type = 'b')


# 2017~2023년 4월 까지의 온라인 음식서비스 이용 거래액
year_2017 <- rep(c('2017'), each = 12)
year_2018 <- rep(c('2018'), each = 12)
year_2019 <- rep(c('2019'), each = 12)
year_2020 <- rep(c('2020'), each = 12)
year_2021 <- rep(c('2021'), each = 12)
year_2022 <- rep(c('2022'), each = 12)
year_2023 <- rep(c('2023'), each = 4)

for(i in 1:12){
  a <- as.character(i)
  if(i<10){
    year_2017[i] <- paste(year_2017[i],".0",a,sep='')
    year_2018[i] <- paste(year_2018[i],".0",a,sep='')
    year_2019[i] <- paste(year_2019[i],".0",a,sep='')
    year_2020[i] <- paste(year_2020[i],".0",a,sep='')
    year_2021[i] <- paste(year_2021[i],".0",a,sep='')
    year_2022[i] <- paste(year_2022[i],".0",a,sep='')
  } else{
    year_2017[i] <- paste(year_2017[i],".",a,sep='')
    year_2018[i] <- paste(year_2018[i],".",a,sep='')
    year_2019[i] <- paste(year_2019[i],".",a,sep='')
    year_2020[i] <- paste(year_2020[i],".",a,sep='')
    year_2021[i] <- paste(year_2021[i],".",a,sep='')
    year_2022[i] <- paste(year_2022[i],".",a,sep='')
  }
}
for(i in 1:4){
  a <- as.character(i)
  year_2023[i] <- paste(year_2023[i],".0",a,sep = '')
}

year <- c(year_2017,year_2018,year_2019,year_2020,year_2021,year_2022,year_2023)

foodservice <- read.csv(file = "온라인 음식서비스 이용 거래액.csv", fileEncoding = 'euc-kr')
foodservice <- foodservice[-1,]

foodservice_sum <- foodservice[,2]

par(mar=c(5,5,5,5))
plot(c(1:76), foodservice_sum,
     main='2017~2023년 4월 까지의 온라인 음식서비스 이용 거래액',
     xaxt="n", las=0, col='red', type='b',
     lty=1, xlab='연도.월',ylab='온라인 음식서비스 이용 거래액(단위: 백만원)')
axis(side=1, at=1:76, labels=year)



#########################################################################
#ppt에 삽입되지 않은 가공된 데이터와 그래프 코드들
#########################################################################


appropriate_amount <- read.xlsx('소비자 선정 적정 배달.xlsx', header = T, sheetIndex = 1)
appropriate_amount_table <- appropriate_amount$비율
names(appropriate_amount_table) <- appropriate_amount$가격
appropriate_amount_table
barplot(appropriate_amount_table,
        main = '소비자가 생각하는 적정 배달비',
        xlab = '배달비(원)',
        ylab = '비율(%)',
        col = c('black', 'black', 'orange', 'orange', 'red', 'yellow', 'yellow', 'black', 'black', 'black'))


# 현재 배달비 현황과 관련된 평균과 같은 데이터, 과거와 현재 비교
delivery <- read.csv(file = '배달비.csv',fileEncoding = "CP949", encoding = "UTF-8")
app <- read.csv(file = '어플 사용자.csv',fileEncoding = "CP949", encoding = "UTF-8")
delibery_5 <- read.csv(file = '23년 5월 배달비 자료.csv',fileEncoding = "CP949", encoding = "UTF-8")
par(mfrow = c(1,1))

#배민
bamin1mean_values <- data.frame(month = character(), mean_value = numeric())

for (i in 5:length(colnames(delivery))) {
  month <- colnames(delivery)[i]
  mean_value <- mean(delivery[[month]][1:4], na.rm = TRUE)
  bamin1mean_values <- rbind(bamin1mean_values, data.frame(month = month, mean_value = mean_value))
}

bamin <- bamin1mean_values$mean_value

#배민
bamin1mean_values <- data.frame(month = character(), mean_value = numeric())

for (month in 5:length(colnames(delivery))) {
  month_data <- as.numeric(delivery[[month]][1:4])
  mean_value <- mean(month_data, na.rm = TRUE)
  if (!is.na(mean_value)) {
    bamin1mean_values <- rbind(bamin1mean_values, data.frame(month = month, mean_value = mean_value))
  }
}

bamin <- bamin1mean_values$mean_value


#요기요
Yogimean_values <- data.frame(month = character(), mean_value = numeric()) # Initialize an empty data frame

for (month in 5:length(colnames(delivery))) {
  mean_value <- mean(delivery[[month]], na.rm = TRUE) # Calculate mean for the entire column
  Yogimean_values <- rbind(Yogimean_values, data.frame(month = month, mean_value = mean_value))
}

yogiyo <- Yogimean_values$mean_value

#쿠팡
Gupangmean_values <- data.frame(month = character(), mean_value = numeric())

for (month in 5:length(colnames(delivery))) {
  mean_value <- mean(delivery[[month]][13:16])
  Gupangmean_values <- rbind(Gupangmean_values, data.frame(month = month, mean_value = mean_value))
}

cupang <- Gupangmean_values$mean_value

#배달비가 2022년도 부터 지속해서 계속 증가하는걸 볼 수 있는 그래프
plot(bamin, 
     type = "l", 
     xlab = "평균", 
     ylab = "배달비", 
     main = "어플 평균 배달비", 
     xaxt = "n",
     col = 'red', 
     ylim = c(1000, 5000))
axis(side = 1, at = 1:16, labels = c("2022.2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월", "2023.1월","2월","3월","4월",'5월'))



lines(yogiyo,
      col = 'purple')

lines(cupang,
      col = 'green')

legend_text <- c( '배민', '요기요', '쿠팡이츠')
legend_colors <- c('red', 'purple', 'green')
legend("topright", legend = legend_text, col = legend_colors, lty = 1, cex = 0.8)

#어플 사용자 그래프
plot(app$배달의민족,
     type = "l",
     xlab = "년도", 
     ylab = "어플 사용자(만)", 
     main = "년도별 어플 사용자", 
     xaxt = "n",
     col = 'red',
     ylim = c(200, 2500))
axis(side = 1, at = 1:21, labels = c("2021.6월", "7월", "8월", "9월", "10월", "11월", "12월", "2022.1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월", "2023.1월", "2월"))

lines(app$요기요,
      col = 'blue')

lines(app$쿠팡이츠,
      col = 'green')

legend_text <- c('배민의민족','요기요', '쿠팡이츠')
legend_colors <- c('red', 'blue', 'green')
legend("topright", legend = legend_text, col = legend_colors, lty = 1, cex = 0.8)

delibery2 <- subset(delibery_5, 거리 == '2km 미만')
delibery2_3 <- subset(delibery_5, 거리 == '2~3km 미만')
delibery3_4 <- subset(delibery_5, 거리 == '3~4km 미만')

#배민
bamin2 <- as.numeric(gsub(",", "", delibery2$배달의민족..배달의.민족..묶음.배달.))
bamin2_3 <- as.numeric(gsub(",", "", delibery2_3$배달의민족..배달의.민족..묶음.배달.))
bamin3_4 <- as.numeric(gsub(",", "", delibery3_4$배달의민족..배달의.민족..묶음.배달.))

#배민1
bamin1_2 <- as.numeric(gsub(",", "", delibery2$배민1..배달의민족..단건배달.))
bamin1_2_3 <- as.numeric(gsub(",", "", delibery2_3$배민1..배달의민족..단건배달.))
bamin1_3_4 <- as.numeric(gsub(",", "", delibery3_4$배민1..배달의민족..단건배달.))

#요기요
yogiyo2 <- as.numeric(gsub(",", "", delibery2$요기요..요기요.익스프레스.))
yogiyo2_3 <- as.numeric(gsub(",", "", delibery2_3$요기요..요기요.익스프레스.))
yogiyo3_4 <- as.numeric(gsub(",", "", delibery3_4$요기요..요기요.익스프레스.))

#쿠팡
copang2 <- as.numeric(gsub(",", "", delibery2$쿠팡이츠))
copang2_3 <- as.numeric(gsub(",", "", delibery2_3$쿠팡이츠))
copang3_4 <- as.numeric(gsub(",", "", delibery3_4$쿠팡이츠))


# 빈 데이터프레임 생성
distance <- data.frame()

# 각 변수의 항목을 순회하면서 더한 값을 데이터프레임에 추가
for (i in 1:length(bamin2)) {
  row_sum <- sum(bamin2[i], bamin1_2[i], yogiyo2[i], copang2[i], na.rm = TRUE)/3
  distance[i, "2km 미만"] <- row_sum
}

# 각 변수의 항목을 순회하면서 더한 값을 데이터프레임에 추가
for (i in 1:length(bamin2_3)) {
  row_sum <- sum(bamin2_3[i], bamin1_2_3[i], yogiyo2_3[i], copang2_3[i], na.rm = TRUE)/3
  distance[i, "2~3km 미만"] <- row_sum
}

# 각 변수의 항목을 순회하면서 더한 값을 데이터프레임에 추가

for (i in 1:length(bamin3_4)) {
  row_sum <- sum(bamin3_4[i], bamin1_3_4[i], yogiyo3_4[i], copang3_4[i], na.rm = TRUE)/3
  distance[i, "3~4km미만"] <- row_sum
}

boxplot(distance$`2km 미만`,
        distance$`2~3km 미만`,
        distance$`3~4km미만`,
        xlab = '거리별',
        ylab = '배달비(원)',
        main = "23.5월 배달의 민족 배달비",
        na.rm = TRUE)
axis(side = 1, at = 1:3, labels = c("2km미만", "2~3km 미만", "3~4km미만"))


first_quartile <- quantile(distance$`2km 미만`, 0.25, na.rm = TRUE)
first_quartile
second_quartile <- quantile(distance$`2km 미만`, 0.5, na.rm = TRUE)
second_quartile
third_quartile <- quantile(distance$`2km 미만`, 0.75, na.rm = TRUE)
third_quartile
mean_of_quartiles <- mean(c(first_quartile, second_quartile, third_quartile))
print(mean_of_quartiles)

first_quartile <- quantile(distance$`2~3km 미만`, 0.25, na.rm = TRUE)
first_quartile
second_quartile <- quantile(distance$`2~3km 미만`, 0.5, na.rm = TRUE)
second_quartile
third_quartile <- quantile(distance$`2~3km 미만`, 0.75, na.rm = TRUE)
third_quartile
mean_of_quartiles <- mean(c(first_quartile, second_quartile, third_quartile))
print(mean_of_quartiles)

first_quartile <- quantile(distance$`3~4km미만`, 0.25, na.rm = TRUE)
first_quartile
second_quartile <- quantile(distance$`3~4km미만`, 0.5, na.rm = TRUE)
second_quartile
third_quartile <- quantile(distance$`3~4km미만`, 0.75, na.rm = TRUE)
third_quartile
mean_of_quartiles <- mean(c(first_quartile, second_quartile, third_quartile))
print(mean_of_quartiles)

mean(distance$`2km 미만`,na.rm = TRUE)
mean(distance$`2~3km 미만`,na.rm = TRUE)
mean(distance$`3~4km미만`,na.rm = TRUE)

sample_sizes <- colSums(!is.na(distance))
sample_sizes

var(distance$`2km 미만`)
var(distance$`2~3km 미만`,na.rm = TRUE)
var(distance$`3~4km미만`,na.rm = TRUE)

sd(distance$`2km 미만`)
sd(distance$`2~3km 미만`,na.rm = TRUE)
sd(distance$`3~4km미만`,na.rm = TRUE)

# opensurvey 자료 이용
opensurvey <- read.xlsx('평소 외식 빈도 및 외식 방법별 이용 비중(2019~2023).xlsx', header=T, sheetIndex=1)

year <- c(2019,2020,2021,2022,2023)
par(mfrow = c(1,3))

# 전체 그룹
opensurvey_total <- opensurvey[, c(2,9,16,23,30)]

opensurvey_total_deli <- opensurvey_total[4,]
opensurvey_total_takeout <- opensurvey_total[3,]
opensurvey_total_direct <- opensurvey_total[2,]

plot(year, opensurvey_total_deli, main='2019~2023년 전체 그룹의 외식 유형',col='red',
     las=1, type='b', lty=1, xlab='연도',ylab='외식 유형(%)',ylim = c(0,60))
lines(year, opensurvey_total_takeout, type='b',col='blue')
lines(year, opensurvey_total_direct, type='b',col='green')
legend('topright', legend = c('배달','테이크아웃','식당/카페 매장'), pch = 1, col=c('red','blue','green'))

# 성별
year_1 <- c(2020,2021,2022,2023)

opensurvey_male <- opensurvey[, c(10,17,24,31)]
opensurvey_female <- opensurvey[, c(11,18,25,32)]

opensurvey_male_deli <- opensurvey_male[4,]
opensurvey_male_takeout <- opensurvey_male[3,]
opensurvey_male_direct <- opensurvey_male[2,]
opensurvey_female_deli <- opensurvey_female[4,]
opensurvey_female_takeout <- opensurvey_female[3,]
opensurvey_female_direct <- opensurvey_female[2,]

plot(year_1, opensurvey_male_deli, main='2020~2023년 남성의 외식 유형',
     las=1, xaxt="n", col='red', type='b', lty=1, xlab='연도',
     ylab='외식 유형(%)', ylim = c(0,60))
lines(year_1, opensurvey_male_takeout, type='b',col='blue')
lines(year_1, opensurvey_male_direct, type='b',col='green')
# x축에 들어갈 내용
axis(side=1, at=seq(2020,2023,by=1))
legend('topright', legend = c('배달','테이크아웃','식당/카페 매장'),
       pch = 1, col=c('red','blue','green'))

plot(year_1, opensurvey_female_deli, main='2020~2023년 여성의 외식 유형',
     las=1, xaxt="n", col='red', type='b', lty=1,
     xlab='연도',ylab='외식 유형(%)', ylim = c(0,60))
lines(year_1, opensurvey_female_takeout, type='b',col='blue')
lines(year_1, opensurvey_female_direct, type='b',col='green')
# x축에 들어갈 내용
axis(side=1, at=seq(2020,2023,by=1))
legend('topright', legend = c('배달','테이크아웃','식당/카페 매장'),
       pch = 1, col=c('red','blue','green'))

par(mfrow = c(1,1))

